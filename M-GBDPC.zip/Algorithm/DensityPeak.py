import numpy as np


class DensityPeak:

    def __init__(self, distanceMatrix, dcRatio=0.2, clusterNumRatio=0.01, dcType="max", kernel="gaussian"):
        self.distance_m = distanceMatrix
        self.dcRatio_f = dcRatio
        self.dcType = dcType
        self.kernel = kernel
        self.clusterCenterRatio_f = clusterNumRatio
        self.densities_l = []
        self.masters_l = []
        self.distanceToMaster_l = []
        self.representativeness_l = []
        self.clusterCenter_l = []
        self.numSample = 0
        self.dc_f = 0
        self.maxDistance = 0
        self.label_l = []
        self.clusters_d = {}
        self.__initDensityPeak()

    def __initDensityPeak(self):
        self.numSample = len(self.distance_m)
        self.maxDistance = self.getMaxDistance()
        self.dc_f = self.getDc()
        self.densities_l = self.computeDensities()
        self.computeDistanceToMaster()
        self.computePriority()

    def getDc(self):
        resultDc = 0.0
        if self.dcType == "max":
            resultDc = self.maxDistance
        elif self.dcType == "ave":
            resultDc = np.mean(self.distance_m)
        elif self.dcType == "min":
            resultDc = np.min(self.distance_m)
        return resultDc * self.dcRatio_f

    def getMaxDistance(self):
        return np.max(self.distance_m)

    def computeDensities(self):
        if self.kernel == 'gaussian':
            temp_local_density_list = np.sum(1 / (np.exp(np.power(self.distance_m / self.dc_f, 2))), axis=1)
            return temp_local_density_list
        elif self.kernel == 'cutoff':
            temp_local_density_list = []
            for i in range(0, self.numSample):
                temp_local_density_list.append(self.cutoff_kernel(i))
            return temp_local_density_list

    def gaussian_kernel(self, i):
        tempDensity = 0
        for j in range(len(self.distance_m[i])):
            tempDistance = self.distance_m[i][j]
            tempDensity += np.exp(-(tempDistance / self.dc_f) ** 2)
        return tempDensity

    def cutoff_kernel(self, i):
        tempDensity = 0
        for j in range(len(self.distance_m[i])):
            tempDistance = self.distance_m[i][j]
            tempDensity += self.F(tempDistance - self.dc_f)
        return tempDensity

    def F(self, x):
        if x < 0:
            return 1
        else:
            return 0

    def computeDistanceToMaster(self):
        tempSortDensityIndex = np.argsort(self.densities_l)[::-1]
        self.distanceToMaster_l = np.zeros(self.numSample)
        self.distanceToMaster_l[tempSortDensityIndex[0]] = float('inf')
        self.masters_l = np.zeros(self.numSample, dtype=int)
        self.masters_l[tempSortDensityIndex[0]] = 0

        for i in range(1, self.numSample):
            tempIndex = tempSortDensityIndex[i]
            self.masters_l[tempIndex] = tempSortDensityIndex[
                np.argmin(self.distance_m[tempIndex][tempSortDensityIndex[:i]])]
            self.distanceToMaster_l[tempIndex] = np.min(self.distance_m[tempIndex][tempSortDensityIndex[:i]])

    def computePriority(self):
        self.representativeness_l = np.multiply(self.densities_l, self.distanceToMaster_l)

    def getLabel(self, i):
        if self.label_l[i] < 0:
            return self.label_l[i]
        else:
            return self.getLabel(self.masters_l[i])

    def getClusterCenter(self):
        n = int(self.numSample * self.clusterCenterRatio_f)
        return np.argsort(self.representativeness_l)[-n:][::-1]

    def cluster(self):
        n = int(self.numSample * self.clusterCenterRatio_f)
        self.cluster2(n=n)

    def cluster2(self, n=3):
        self.label_l = np.zeros(self.numSample, dtype=int)
        self.clusterCenter_l = np.argsort(self.representativeness_l)[-n:][::-1]
        for i in range(n):
            self.label_l[self.clusterCenter_l[i]] = -i - 1
        for i in range(self.numSample):
            if self.label_l[i] < 0:
                continue
            self.label_l[i] = self.getLabel(self.masters_l[i])
        self.clusters_d = {key: [] for key in self.label_l[self.clusterCenter_l]}
        for i in self.label_l[self.clusterCenter_l]:
            self.clusters_d[i] += [j for j in range(self.numSample) if self.label_l[j] == i]

    @staticmethod
    def getDistanceByEuclid(instance1, instance2):
        dist = 0
        for key in range(len(instance1)):
            dist += (float(instance1[key]) - float(instance2[key])) ** 2
        return dist ** 0.5
