import scipy.io
import numpy as np
import csv
import pickle
import os


def txt_read(file_path):
    data_list = []
    with open(file_path, 'r') as f:
        data_all = f.readlines()
        for data in data_all:
            content = data.split()
            if len(content) == 3:
                x, y, label = content
                data_list.append([float(x), float(y), int(label)])
            else:
                x, y = content
                data_list.append([float(x), float(y), 0])
    return data_list


def mat_read(file_path):
    data_all = scipy.io.loadmat(file_path)
    if 'data_Iris' in file_path:
        data = data_all['fea']
        label = data_all['gt']
    elif 'data_DBRHD' in file_path:
        data = data_all['fea']
        label = data_all['gt']
    elif 'data_COIL20' in file_path:
        data = data_all['fea']
        label = data_all['gt']
    elif 't4_nonoise' in file_path:
        data = data_all['t42']
        label = np.zeros((len(data), 1))
    elif 't4' in file_path:
        data = data_all['t4']
        label = np.zeros((len(data), 1))
    elif 'Da6' in file_path:
        data = data_all['A']
        label = np.zeros((len(data), 1))
    elif 'R15' in file_path:
        data = data_all['R15']
        label = data_all['labels']
    else:
        data = data_all['fea']
        label = data_all['gt']
    data_list = np.hstack((data, label))
    return data_list


def csv_read(file_path, has_head=False):
    data_list = []
    with open(file_path, encoding='utf-8-sig') as f:
        f_csv = csv.reader(f)
        if has_head:
            pass
        if 'real_data' in file_path:
            for row in f_csv:
                data_temp = []
                for i in range(1, len(row)):
                    data_temp.append(row[i])
                data_temp.append(row[0])
                data_list.append(data_temp)
        else:
            for row in f_csv:
                if len(row) >= 3:
                    data_list.append(row)
                else:
                    data_list.append([row[0], row[1], 0])
    return data_list


def txt_write(data, save_path, isLines=False):
    if not isLines:
        with open(save_path, 'w', encoding='utf-8') as f:
            for line in data:
                f.write(str(line[0]) + '\t' + str(line[1]) + '\n')
    else:
        with open(save_path, 'w', encoding='utf-8') as f:
            for line in data:
                for element in line:
                    f.write(str(element) + '\t')
                f.write('\n')


def unpickle(file_path):
    data_list = []
    file_names = os.listdir(file_path)
    for index, file_name in enumerate(file_names):
        if 'data_batch' in file_name:
            file_direct_path = file_path + '/' + file_name
            labels = []
            with open(file_direct_path, 'rb') as f:
                data_temp = pickle.load(f, encoding='bytes')
                for key, val in data_temp.items():
                    key = key.decode('utf-8')
                    if key == 'labels':
                        labels = np.array(val).reshape(-1, 1)
                    if key == 'data':
                        data_all = np.append(np.array(val), labels, axis=1)
                        if len(data_list) > 0:
                            data_list = np.concatenate((data_list, data_all), axis=0)
                        else:
                            data_list = np.copy(data_all)
            break
    # print(len(data_list), data_list.shape)
    # exit(0)
    return data_list
