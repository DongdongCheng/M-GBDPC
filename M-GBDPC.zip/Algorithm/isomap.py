from sklearn.manifold import Isomap, MDS
from sklearn.neighbors import KDTree
from sklearn.utils.graph import graph_shortest_path
from sklearn.decomposition import KernelPCA
from sklearn.metrics.pairwise import pairwise_kernels
from sklearn.preprocessing import KernelCenterer
from sklearn.utils.extmath import svd_flip
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import eigsh
from scipy import linalg
from scipy.spatial.distance import pdist, cdist, squareform
from scipy.sparse.csgraph import shortest_path
import numpy as np
import granular_ball_clustering
import granular_ball_process
import data_display
import Naturalneighbor


def function_call(data_list, n_components=2, n_neighbors=5, is_mds=False):
    if is_mds:
        return MDS(n_components=n_components).fit_transform(data_list)
    else:
        return Isomap(n_components=n_components, n_neighbors=n_neighbors, path_method='D', neighbors_algorithm='kd_tree').fit_transform(data_list)


def mds(data_list, n_components=2):
    dist = np.square(data_list)
    mat_length = len(data_list)
    dist_i = np.zeros(mat_length)
    dist_j = np.zeros(mat_length)
    b = np.zeros((mat_length, mat_length))
    for i in range(mat_length):
        dist_i[i] = np.mean(dist[i, :])
        dist_j[i] = np.mean(dist[:, i])
    dist_ij = np.mean(dist)
    for i in range(mat_length):
        for j in range(mat_length):
            b[i][j] = -0.5 * (dist[i][j] - dist_i[i] - dist_j[j] + dist_ij)
    eva, evt = np.linalg.eigh(b)
    # 保持结果一致性
    evt, _ = svd_flip(evt, np.empty_like(evt).T)
    index_sort = np.argsort(-eva)[:n_components]
    eva_sort_dia = np.diag(eva[index_sort])
    evt_sort = evt[:, index_sort]
    z = np.dot(evt_sort, np.sqrt(eva_sort_dia))
    return z, eva_sort_dia, evt_sort


def distance_based_triangulation(eva_sort_dia, evt_sort):
    z = np.dot(evt_sort, 1/np.sqrt(eva_sort_dia))
    pass


def old_method_implementation(data_list, n_components=2, leaf_size=30, k_neighbor=6):
    kd_tree = KDTree(data_list, leaf_size=leaf_size)
    knn_distance, knn_index = kd_tree.query(data_list, k=k_neighbor)
    knn_distance = np.ravel(knn_distance)
    n_queries = knn_index.shape[0]
    n_samples = data_list.shape[0]
    n_nonzero = k_neighbor
    index_count = n_queries * n_nonzero
    index_flag = np.arange(0, index_count + 1, n_nonzero)
    knn_graph = csr_matrix((knn_distance, knn_index.ravel(), index_flag), shape=(n_queries, n_samples))
    distance_mat = shortest_path(knn_graph, method='D', directed=False)
    distance_mat[np.isinf(distance_mat)] = 0
    distance_mat_max = np.max(distance_mat) * 2
    for i in range(len(distance_mat)):
        for j in range(len(distance_mat)):
            if i != j and distance_mat[i][j] == 0:
                distance_mat[i][j] = distance_mat_max
    ans = mds(distance_mat, n_components)
    return ans


def method_implementation(data_list, n_components=2, leaf_size=30, k_neighbor=6):
    kd_tree = KDTree(data_list, leaf_size=leaf_size)
    knn_distance, knn_index = kd_tree.query(data_list, k=k_neighbor)

    isolated_index = []
    for i in range(len(data_list)):
        min_distance = knn_distance[i][1]
        min_distance_index = knn_index[i][1]
        for j in range(k_neighbor):
            if i not in knn_index[knn_index[i][j]]:
                knn_index[i][j] = i
                knn_distance[i][j] = 0
        if np.max(knn_distance[i][1:]) == 0:
            knn_index[i][1] = min_distance_index
            knn_distance[i][1] = min_distance
            isolated_index.append([i, min_distance_index])

    clusters = []
    knn_index_copy = [list(i) for i in np.copy(knn_index)]
    for i in isolated_index:
        knn_index_copy[i[1]].append(i[0])
    in_cluster_index = np.array([])
    for i in range(len(knn_index_copy)):
        if i in in_cluster_index:
            continue
        else:
            new_cluster = np.array([i])
            in_cluster = np.array([j for j in knn_index_copy[i][1:] if j not in new_cluster])
            while len(in_cluster) > 0:
                new_cluster = np.hstack((new_cluster, in_cluster[0]))
                in_cluster_candidate = np.array([j for j in knn_index_copy[in_cluster[0]][1:] if j not in new_cluster
                                                 and j not in in_cluster])
                in_cluster = np.delete(in_cluster, [0])
                if len(in_cluster_candidate) > 0:
                    in_cluster = np.hstack((in_cluster, in_cluster_candidate))
            clusters.append(new_cluster)
            in_cluster_index = np.hstack((in_cluster_index, new_cluster))

    full_count = 0
    while len(clusters) > n_components:
        cluster_min_size = len(data_list)
        cluster_min_index = -1
        for i, cluster in enumerate(clusters):
            cluster_size = len(cluster)
            if cluster_size < cluster_min_size:
                cluster_min_size = cluster_size
                cluster_min_index = i
        cluster_min_distance = -1
        cluster_min_distance_index = -1
        key_point_index1 = -1
        key_point_index2 = -1
        for i, cluster in enumerate(clusters):
            if i == cluster_min_index:
                continue
            else:
                cluster_distance_mat = cdist(data_list[clusters[cluster_min_index]], data_list[cluster], 'euclidean')
                cluster_distance_mat_min_distance = np.min(cluster_distance_mat)
                if cluster_min_distance < 0 or cluster_min_distance > cluster_distance_mat_min_distance:
                    cluster_min_distance = cluster_distance_mat_min_distance
                    cluster_min_distance_index = i
                    key_point_index1 = np.argmin(cluster_distance_mat) // len(cluster)
                    key_point_index2 = np.argmin(cluster_distance_mat) % len(cluster)
        is_full = True
        for i, index in enumerate(knn_index[clusters[cluster_min_index][key_point_index1]]):
            if i != 0 and index == knn_index[clusters[cluster_min_index][key_point_index1]][0]:
                is_full = False
                knn_index[clusters[cluster_min_index][key_point_index1]][i] = clusters[cluster_min_distance_index][key_point_index2]
                knn_distance[clusters[cluster_min_index][key_point_index1]][i] = cluster_min_distance
                break
        if is_full:
            for i, index in enumerate(knn_index[clusters[cluster_min_distance_index][key_point_index2]]):
                if i != 0 and index == knn_index[clusters[cluster_min_distance_index][key_point_index2]][0]:
                    is_full = False
                    knn_index[clusters[cluster_min_distance_index][key_point_index2]][i] = clusters[cluster_min_index][key_point_index1]
                    knn_distance[clusters[cluster_min_distance_index][key_point_index2]][i] = cluster_min_distance
                    break
        if is_full:
            full_count += 1
            knn_index_list = knn_index.tolist()
            knn_distance_list = knn_distance.tolist()
            for i in range(len(knn_index_list)):
                if i == clusters[cluster_min_index][key_point_index1]:
                    knn_index_list[i].append(clusters[cluster_min_distance_index][key_point_index2])
                    knn_distance_list[i].append(cluster_min_distance)
                elif i == clusters[cluster_min_distance_index][key_point_index2]:
                    knn_index_list[i].append(clusters[cluster_min_index][key_point_index1])
                    knn_distance_list[i].append(cluster_min_distance)
                else:
                    knn_index_list[i].append(knn_index_list[i][0])
                    knn_distance_list[i].append(knn_distance_list[i][0])
            knn_index = np.array(knn_index_list)
            knn_distance = np.array(knn_distance_list)
        new_cluster = np.hstack((clusters[cluster_min_index], clusters[cluster_min_distance_index]))
        del clusters[max(cluster_min_index, cluster_min_distance_index)]
        del clusters[min(cluster_min_index, cluster_min_distance_index)]
        clusters.append(new_cluster)
    knn_distance = np.ravel(knn_distance)
    n_queries = knn_index.shape[0]
    n_samples = data_list.shape[0]
    n_nonzero = k_neighbor + full_count
    index_count = n_queries * n_nonzero
    index_flag = np.arange(0, index_count + 1, n_nonzero)
    knn_graph = csr_matrix((knn_distance, knn_index.ravel(), index_flag), shape=(n_queries, n_samples))

    distance_mat = shortest_path(knn_graph, method='D', directed=False)
    distance_mat[np.isinf(distance_mat)] = 0
    distance_mat_max = np.max(distance_mat) * 2
    for i in range(len(distance_mat)):
        for j in range(len(distance_mat)):
            if i != j and distance_mat[i][j] == 0:
                distance_mat[i][j] = distance_mat_max
    ans = mds(distance_mat, n_components)
    return ans


def gb_dis_method_implementation(data_list, n_components=2, k_neighbor=6, deta=0.1):
    center_list = []
    for gb in data_list:
        center_list.append(gb.mean(axis=0))
    gb_distance = granular_ball_process.get_gb_affinity(data_list, center_list, deta)
    knn_distance, knn_index = [], []
    for gd in gb_distance:
        distance = []
        index = []
        gd_max = np.max(gd)
        for times in range(k_neighbor):
            d = np.min(gd)
            i = np.argmin(d)
            distance.append(d)
            index.append(i)
            gd[i] = 2 * gd_max
        knn_distance.append(distance)
        knn_index.append(index)
    knn_index = np.array(knn_index)
    knn_distance = np.array(knn_distance)
    full_count = 0

    knn_distance = np.ravel(knn_distance)
    n_queries = knn_index.shape[0]
    n_samples = gb_distance.shape[0]
    n_nonzero = k_neighbor + full_count
    index_count = n_queries * n_nonzero
    index_flag = np.arange(0, index_count + 1, n_nonzero)
    knn_graph = csr_matrix((knn_distance, knn_index.ravel(), index_flag), shape=(n_queries, n_samples))

    distance_mat = shortest_path(knn_graph, method='D', directed=False)

    distance_mat[np.isinf(distance_mat)] = 0
    distance_mat_max = np.max(distance_mat) * 2
    for i in range(len(distance_mat)):
        for j in range(len(distance_mat)):
            if i != j and distance_mat[i][j] == 0:
                distance_mat[i][j] = distance_mat_max
    ans = mds(distance_mat, n_components)
    return ans


def gb_dis_nn_method_implementation(data_list, n_components=2, k_neighbor=-1):
    gb_list = granular_ball_clustering.gbc(data_list)
    center_list = []
    for gb in gb_list:
        center_list.append(gb.mean(axis=0))
    gb_distance = granular_ball_process.get_gb_distance(gb_list)
    natural_neighbor = Naturalneighbor.NNSearch(gb_distance)
    turn_num, nn, rnn, dis_index = natural_neighbor.natural_search()
    key_num = turn_num
    if 0 <= k_neighbor < turn_num + 2:
        key_num = k_neighbor
    knn_distance, knn_index = [], []
    for i in range(len(nn)):
        index = [i]
        distance = [0]
        natural_neighbor_index = [value for value in nn[i] if value in rnn[i]]
        if len(natural_neighbor_index) > key_num - 1:
            natural_neighbor_index = natural_neighbor_index[:key_num - 1]
        index = index + natural_neighbor_index
        distance = distance + list(dis_index[i][0][natural_neighbor_index])
        if len(index) < key_num:
            for j in range(key_num - len(index)):
                index.append(i)
                distance.append(0)
        knn_index.append(index)
        knn_distance.append(distance)
    knn_index = np.array(knn_index)
    knn_distance = np.array(knn_distance)

    clusters = []
    knn_index_copy = [list(i) for i in np.copy(knn_index)]
    in_cluster_index = np.array([])
    for i in range(len(knn_index_copy)):
        if i in in_cluster_index:
            continue
        else:
            new_cluster = np.array([i])
            in_cluster = np.array([j for j in knn_index_copy[i][1:] if j not in new_cluster])
            while len(in_cluster) > 0:
                new_cluster = np.hstack((new_cluster, in_cluster[0]))
                in_cluster_candidate = np.array(
                    [j for j in knn_index_copy[in_cluster[0]][1:] if j not in new_cluster
                     and j not in in_cluster])
                in_cluster = np.delete(in_cluster, [0])
                if len(in_cluster_candidate) > 0:
                    in_cluster = np.hstack((in_cluster, in_cluster_candidate))
            clusters.append(new_cluster)
            in_cluster_index = np.hstack((in_cluster_index, new_cluster))

    print(len(clusters))
    full_count = 0
    while len(clusters) > n_components:
        cluster_min_size = len(data_list)
        cluster_min_index = -1
        for i, cluster in enumerate(clusters):
            cluster_size = np.sum([len(gb) for gb in np.array(gb_list)[cluster]])
            if cluster_size < cluster_min_size:
                cluster_min_size = cluster_size
                cluster_min_index = i
        cluster_min_distance = -1
        cluster_min_distance_index = -1
        key_point_index1 = -1
        key_point_index2 = -1
        for i, cluster in enumerate(clusters):
            if i == cluster_min_index:
                continue
            else:
                cluster_min_gb = [gb for gb in np.array(gb_list)[clusters[cluster_min_index]]]
                cluster_gb = [gb for gb in np.array(gb_list)[cluster]]
                cluster_distance_mat = cdist(np.vstack(cluster_min_gb), np.vstack(cluster_gb), 'euclidean')
                cluster_distance_mat_min_distance = np.min(cluster_distance_mat)
                if cluster_min_distance < 0 or cluster_min_distance > cluster_distance_mat_min_distance:
                    cluster_min_distance = cluster_distance_mat_min_distance
                    cluster_min_distance_index = i
                    key_point_index = np.argmin(cluster_distance_mat)
                    key_point1 = (key_point_index // len(np.vstack(cluster_gb))) + 1
                    key_point2 = (key_point_index % len(np.vstack(cluster_gb))) + 1
                    for key_point, gb in enumerate(cluster_min_gb):
                        if key_point1 - len(gb) <= 0:
                            key_point_index1 = key_point
                            break
                        key_point1 -= len(gb)
                    for key_point, gb in enumerate(cluster_gb):
                        if key_point2 - len(gb) <= 0:
                            key_point_index2 = key_point
                            break
                        key_point2 -= len(gb)
        is_full = True
        for i, index in enumerate(knn_index[clusters[cluster_min_index][key_point_index1]]):
            if i != 0 and index == knn_index[clusters[cluster_min_index][key_point_index1]][0]:
                is_full = False
                knn_index[clusters[cluster_min_index][key_point_index1]][i] = clusters[cluster_min_distance_index][
                    key_point_index2]
                knn_distance[clusters[cluster_min_index][key_point_index1]][i] = cluster_min_distance
                break
        if is_full:
            for i, index in enumerate(knn_index[clusters[cluster_min_distance_index][key_point_index2]]):
                if i != 0 and index == knn_index[clusters[cluster_min_distance_index][key_point_index2]][0]:
                    is_full = False
                    knn_index[clusters[cluster_min_distance_index][key_point_index2]][i] = \
                    clusters[cluster_min_index][key_point_index1]
                    knn_distance[clusters[cluster_min_distance_index][key_point_index2]][i] = cluster_min_distance
                    break
        if is_full:
            full_count += 1
            knn_index_list = knn_index.tolist()
            knn_distance_list = knn_distance.tolist()
            for i in range(len(knn_index_list)):
                if i == clusters[cluster_min_index][key_point_index1]:
                    knn_index_list[i].append(clusters[cluster_min_distance_index][key_point_index2])
                    knn_distance_list[i].append(cluster_min_distance)
                elif i == clusters[cluster_min_distance_index][key_point_index2]:
                    knn_index_list[i].append(clusters[cluster_min_index][key_point_index1])
                    knn_distance_list[i].append(cluster_min_distance)
                else:
                    knn_index_list[i].append(knn_index_list[i][0])
                    knn_distance_list[i].append(knn_distance_list[i][0])
            knn_index = np.array(knn_index_list)
            knn_distance = np.array(knn_distance_list)
        new_cluster = np.hstack((clusters[cluster_min_index], clusters[cluster_min_distance_index]))
        del clusters[max(cluster_min_index, cluster_min_distance_index)]
        del clusters[min(cluster_min_index, cluster_min_distance_index)]
        clusters.append(new_cluster)
    print(len(clusters))

    knn_distance = np.ravel(knn_distance)
    n_queries = knn_index.shape[0]
    n_samples = gb_distance.shape[0]
    n_nonzero = key_num + full_count
    index_count = n_queries * n_nonzero
    index_flag = np.arange(0, index_count + 1, n_nonzero)
    knn_graph = csr_matrix((knn_distance, knn_index.ravel(), index_flag), shape=(n_queries, n_samples))
    kg = knn_graph.toarray()
    x_list = []
    y_list = []
    count = 0
    for i in range(n_queries):
        for j in range(n_queries):
            if kg[i][j]:
                count += 1
                x = []
                y = []
                x.append(center_list[i][0])
                x.append(center_list[j][0])
                y.append(center_list[i][1])
                y.append(center_list[j][1])
                x_list.append(x)
                y_list.append(y)
    data_display.plot_dot(center_list)
    data_display.draw_line(x_list, y_list)
    distance_mat = graph_shortest_path(knn_graph, method='D', directed=False)
    distance_mat_max = np.max(distance_mat) * 2
    for i in range(len(distance_mat)):
        for j in range(len(distance_mat)):
            if i != j and distance_mat[i][j] == 0:
                distance_mat[i][j] = distance_mat_max
    ans = mds(distance_mat, n_components)
    return ans


def test(data_list, n_components=2, leaf_size=30, k_neighbor=6):
    kd_tree = KDTree(data_list, leaf_size=leaf_size)
    knn_distance, knn_index = kd_tree.query(data_list, k=k_neighbor)
    knn_distance = np.ravel(knn_distance)
    n_queries = knn_index.shape[0]
    n_samples = data_list.shape[0]
    n_nonzero = k_neighbor
    index_count = n_queries * n_nonzero
    index_flag = np.arange(0, index_count + 1, n_nonzero)
    knn_graph = csr_matrix((knn_distance, knn_index.ravel(), index_flag), shape=(n_queries, n_samples))

    distance_mat = graph_shortest_path(knn_graph, method='D', directed=False)
    g = distance_mat ** 2
    g *= -0.5
    pk = pairwise_kernels(g, None, metric="precomputed", filter_params=True)
    rows = np.sum(pk, axis=0) / n_samples
    cols = (np.sum(pk, axis=1) / rows.shape[0])[:, np.newaxis]
    means = rows.sum() / n_samples
    pk -= rows
    pk -= cols
    pk += means
    kc = pk

    if kc.shape[0] > 200 and n_components < 10:
        eig_solver = 'ar_pack'
    else:
        eig_solver = 'dense'
    if eig_solver == 'dense':
        lambdas_, alphas_ = linalg.eigh(kc, eigvals=(kc.shape[0] - n_components, kc.shape[0] - 1))
    else:
        v0 = np.random.uniform(-1, 1, kc.shape[0])
        lambdas_, alphas_ = eigsh(kc, n_components, which="LA", v0=v0)
    alphas_, _ = svd_flip(alphas_, np.empty_like(alphas_).T)
    indices = lambdas_.argsort()[::-1]
    lambdas = lambdas_[indices]
    alphas = alphas_[:, indices]
    ans = alphas * np.sqrt(lambdas)
    return ans
