import data_loading
import data_display
import granular_ball_clustering
import granular_ball_process
import isomap
import umap
from sklearn.manifold import TSNE
import time
import numpy as np
from sklearn.cluster import KMeans
from sklearn.utils.graph import graph_shortest_path
import matplotlib.pyplot as plt
from munkres import Munkres, print_matrix
from sklearn.metrics import accuracy_score, normalized_mutual_info_score
from sklearn.preprocessing import MinMaxScaler
from scipy.spatial.distance import pdist, cdist, squareform
from DensityPeak import DensityPeak as Original_DP
from Proposed_DP import DensityPeak as proposed_DP
from sklearn.neighbors import NearestNeighbors
from correlation_algorithm.data import FastDP
from algorithm.HCDC import HCDC
import GranularBallSC


def main_process():
    data_set_name = ['Synthetic/D1.txt', 'Synthetic/D2.txt', 'Synthetic/D3.txt', 'Synthetic/D4.txt', 'Synthetic/D5.txt',
                     'Synthetic/D6.txt', 'Synthetic/D7.txt', 'Synthetic/D8.txt', 'Synthetic/D9.txt',
                     'Synthetic/D10.txt',
                     'Synthetic/D11.txt', 'Synthetic/D12.txt', 'Real/Mushroom.csv', 'Real/CovType.csv',
                     'Real/PenDigits.csv', 'Real/DryBeanDataset.csv']
    dataset_set_clusters = [2, 2, 2, 2, 2,
                            2, 2, 2, 2,
                            2,
                            2, 2, 2, 54,
                            16, 16]
    test_num = 0
    data_set_path = '../datasets/' + data_set_name[test_num]
    if '.txt' in data_set_path:
        data_test = data_loading.txt_read(data_set_path)
    elif '.csv' in data_set_path:
        data_test = data_loading.csv_read(data_set_path)
    else:
        print("Unknown dataset type!")
        return

    data_train = np.array([data[:-1] for data in data_test], dtype='float64')
    real_label = np.array([[data[-1]] for data in data_test], dtype='float64')
    print('Begin test')

    # FastDP
    # label, t1 = FastDP.main(data_train, cluster_number=dataset_set_clusters[test_num], k_neighbor=15)
    # data_res = []
    # if np.min(label) == 0:
    #     for index, data in enumerate(data_train):
    #         data_res.append([data[0], data[1], label[index]])
    # else:
    #     for index, data in enumerate(data_train):
    #         data_res.append([data[0], data[1], label[index] - 1])
    # data_display.show(data_res, 'FastDP')
    # exit()
    #
    # # HCDC
    # label, t2 = HCDC.main(data_train, real_label, cluster_number=dataset_set_clusters[test_num])
    # data_res = []
    # if np.min(label) == 0:
    #     for index, data in enumerate(data_train):
    #         data_res.append([data[0], data[1], label[index]])
    # else:
    #     for index, data in enumerate(data_train):
    #         data_res.append([data[0], data[1], label[index] - 1])
    # data_display.show(data_res, 'HCDC')
    # # exit()
    #
    # # GBSC
    # data_res, t = GranularBallSC.main(data_train, dataset_set_clusters[test_num], deta=0.05)
    # data_display.show(data_res, 'GBSC')
    # print("GBSC run time：%s s" % t)
    # # exit()

    start_time = time.time()
    gb = granular_ball_clustering.gbc(data_train)
    center_list = []
    for gb_ in gb:
        center_list.append(gb_.mean(axis=0))
    gb_ans, _, _ = isomap.method_implementation(np.array(center_list), n_components=dataset_set_clusters[test_num],
                                                k_neighbor=3)

    # dp = proposed_DP(data_train, k=int(len(data_train) * 0.4))
    dp = proposed_DP(gb_ans, k=int(len(gb_ans) * 0.4))
    dp.cluster2(n=dataset_set_clusters[test_num])
    label = np.array([[np.abs(i + 1)] for i in dp.label_l])

    # label = KMeans(n_clusters=dataset_set_clusters[test_num]).fit_predict(gb_ans)[:, np.newaxis]
    data_res = []
    for index, i in enumerate(gb):
        for j in i:
            temp_list = j.tolist()
            temp_list.append(label[index])
            data_res.append(temp_list)
    data_display.show(data_res, 'M-GBDPC')

    label = []
    for i in data_train:
        for j in data_res:
            if i[0] == j[0] and i[1] == j[1]:
                label.append(j[-1])
                break
    label = np.array(label)

    # data_label = [[data[-1]] for data in data_test]
    # data_ans = np.hstack((np.array(data_train), data_label))
    # data_display.show(data_ans, 'real result')
    # label = KMeans(n_clusters=dataset_set_clusters[test_num]).fit_predict(data_train)[:, np.newaxis]
    # data_ans = np.hstack((np.array(data_train), label))
    # data_display.show(data_ans, 'K-means data distribution')
    # data_display.show(data_train, 'data distribution')
    # data_display.plot_dot(data_train, c='black')
    # plt.show()
    # data_display.draw_ball(gb)

    def best_map(L1, L2):
        """L1 should be the labels and L2 should be the clustering number we got"""
        Label1 = np.unique(L1)
        nClass1 = len(Label1)
        Label2 = np.unique(L2)
        nClass2 = len(Label2)
        nClass = np.maximum(nClass1, nClass2)
        G = np.zeros((nClass, nClass))
        for i in range(nClass1):
            ind_cla1 = L1 == Label1[i]
            ind_cla1 = ind_cla1.astype(float)
            for j in range(nClass2):
                ind_cla2 = L2 == Label2[j]
                ind_cla2 = ind_cla2.astype(float)
                G[i, j] = np.sum(ind_cla2 * ind_cla1)
        m = Munkres()
        index = m.compute(-G.T)
        index = np.array(index)
        c = index[:, 1]
        newL2 = np.zeros(L2.shape)
        for i in range(nClass2):
            newL2[L2 == Label2[i]] = Label1[c[i]]
        return newL2

    if len(np.unique(real_label)) > 1:
        label_last = best_map(real_label, label)
        acc = accuracy_score(real_label, label_last)
        print("ACC: " + str(acc))
        nmi = normalized_mutual_info_score(real_label.flatten(), label_last.flatten(), average_method='arithmetic')
        print("NMI: " + str(nmi))


if __name__ == '__main__':
    main_process()
