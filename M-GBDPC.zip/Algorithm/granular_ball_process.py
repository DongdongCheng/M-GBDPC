from sklearn.neighbors import KDTree
from scipy.spatial.distance import pdist, cdist, squareform
import numpy as np
from math import exp


def get_two_gb_distance(gb1, gb2):
    distance_mat = cdist(gb1, gb2, 'euclidean')
    distance_min = np.min(distance_mat)
    return distance_min


def get_gb_distance(gb_list):
    gb_distance = np.zeros((len(gb_list), len(gb_list)))
    for i in range(len(gb_list)):
        for j in range(i+1, len(gb_list)):
            distance = get_two_gb_distance(gb_list[i], gb_list[j])
            gb_distance[i][j] = distance
            gb_distance[j][i] = distance
    return gb_distance


def get_affinitys(data, center, radius1, radius2):
    return np.linalg.norm(data - center) - radius2 - radius1


def get_radius(gb):
    num = len(gb)
    center = gb.mean(0)
    diffMat = np.tile(center, (num, 1)) - gb
    sqDiffMat = diffMat ** 2
    sqDistances = sqDiffMat.sum(axis=1)
    distances = sqDistances ** 0.5
    radius = max(distances)
    return radius


def get_gb_affinity(gb_list, center_list, deta=0.1):
    radius_list = []
    affinity = []
    for gb in gb_list:
        radius_list.append(get_radius(gb))
    for i in range(len(gb_list)):
        temp = []
        for j in range(len(gb_list)):
            if i == j:
                temp.append(0)
                continue
            value = -1 * get_affinitys(center_list[i], center_list[j], radius_list[i], radius_list[j])
            deta_f = 2 * (np.square(deta))
            temp.append(exp(value / deta_f))
        affinity.append(temp)
    affinity = np.asarray(affinity)
    return affinity

