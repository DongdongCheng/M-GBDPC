import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
from mpl_toolkits.mplot3d import Axes3D


plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def show(data_list, title=''):
    plt.title(title)
    color = ['r', 'b', 'g', 'pink', 'purple', 'cyan', 'yellow', 'chocolate', 'orangered', 'lawngreen',
             'maroon', 'y', 'lime', 'deepskyblue', 'violet', 'blueviolet', 'deeppink', 'linen']
    if len(data_list[0]) > 3:
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        for data in data_list:
            ax.scatter(data[0], data[1], data[2], s=5, c=color[int(data[-1])], linewidths=5, alpha=1, marker='o')
    else:
        for data in data_list:
            if len(data) == 3:
                plt.scatter(data[0], data[1], s=5, c=color[int(data[2])], linewidths=5, alpha=1, marker='o')
            elif len(data) > 3:
                plt.scatter(data[0], data[1], s=5, c=color[int(data[-1])], linewidths=5, alpha=1, marker='o')
            else:
                plt.scatter(data[0], data[1], s=5, c=color[0], linewidths=5, alpha=1, marker='o')
    plt.show()


def plot_dot(data_list, c='g', label='data point', linewidths=5, s=5, marker='o'):
    data = np.array(data_list)
    plt.scatter(data[:, 0], data[:, 1], s=s, c=c, linewidths=linewidths, alpha=1, marker=marker,
                label=label)
    plt.legend(loc=1)


def draw_ball(gb_list, c1='black', c2='black'):
    is_isolated = False
    for data in gb_list:
        if len(data) > 1:
            center = data.mean(0)
            radius = np.max((((data - center) ** 2).sum(axis=1) ** 0.5))
            theta = np.arange(0, 2 * np.pi, 0.01)
            x = center[0] + radius * np.cos(theta)
            y = center[1] + radius * np.sin(theta)
            plt.plot(x, y, ls='-', color=c1, lw=0.7)
        else:
            plt.plot(data[0][0], data[0][1], marker='*', color=c2, markersize=3)
            is_isolated = True
    plt.plot([], [], ls='-', color=c1, lw=1.2, label='granular-ball boundary')
    plt.legend(loc=1)
    if is_isolated:
        plt.scatter([], [], marker='*', color=c2, label='isolated point')
        plt.legend(loc=1)
    plt.show()


def draw_line(x_list, y_list, c='black', label='', isShow=True, linewidth=0.5, ls='-'):
    for i in range(len(x_list)):
        plt.plot(x_list[i], y_list[i], c=c, ls=ls, linewidth=linewidth)
    plt.plot([], [], ls='-', color=c, lw=1.2, label=label)
    plt.legend(loc=1)
    if isShow:
        plt.show()


def draw_arrow(x_list, y_list, c='black', label='', isShow=True, linewidth=0.5, shrinkA=1, shrinkB=1):
    for i in range(len(x_list)):
        patch = patches.FancyArrowPatch([x_list[i][0], y_list[i][0]], [x_list[i][1], y_list[i][1]],
                                        ec=c, fc=c, arrowstyle='->', mutation_scale=9, shrinkA=shrinkA, shrinkB=shrinkB)
        plt.gca().add_patch(patch)
        # plt.arrow(x_list[i][0], y_list[i][0], x_list[i][1] - x_list[i][0], y_list[i][1] - y_list[i][0],
        #           linewidth=0.5, head_width=0.5, head_length=0.7, fc=c, ec=c, linestyle='-',
        #           overhang=0.7)
    plt.legend(loc=1)
    if isShow:
        plt.show()


def draw_ball_without_plt(gb_list):
    is_isolated = False
    for data in gb_list:
        if len(data) > 1:
            center = data.mean(0)
            radius = np.max((((data - center) ** 2).sum(axis=1) ** 0.5))
            theta = np.arange(0, 2 * np.pi, 0.01)
            x = center[0] + radius * np.cos(theta)
            y = center[1] + radius * np.sin(theta)
            plt.plot(x, y, ls='-', color='black', lw=0.7)
        else:
            plt.plot(data[0][0], data[0][1], marker='*', color='black', markersize=3)
            is_isolated = True
    plt.plot([], [], ls='-', color='black', lw=1.2, label='granular-ball boundary')
    plt.legend(loc=1)
    if is_isolated:
        plt.scatter([], [], marker='*', color='black', label='isolated point')
        plt.legend(loc=1)


def image_show(pixels):
    red_channel = pixels[:1024].astype(int).reshape((32, 32))
    green_channel = pixels[1024:2048].astype(int).reshape((32, 32))
    blue_channel = pixels[2048:].astype(int).reshape((32, 32))

    image = np.dstack((red_channel, green_channel, blue_channel))

    plt.imshow(image)
    plt.axis('off')
    plt.show()
