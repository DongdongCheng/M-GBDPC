from scipy.spatial.distance import pdist, squareform
import numpy as np


def division(gb_list, gb_list_not):
    gb_list_new = []
    for gb in gb_list:
        if len(gb) > 2:
            ball_1, ball_2 = spilt_ball(gb)
            if len(ball_2) == 0 or len(ball_1) == 0:
                gb_list_not.append(gb)
                continue
            dm_parent = get_dm(gb)
            dm_child_1 = get_dm(ball_1)
            dm_child_2 = get_dm(ball_2)
            # dm_parent = get_dm_2(gb)
            # dm_child_1 = get_dm_2(ball_1)
            # dm_child_2 = get_dm_2(ball_2)
            w = len(ball_1) + len(ball_2)
            w1 = len(ball_1) / w
            w2 = len(ball_2) / w
            w_child = w1 * dm_child_1 + w2 * dm_child_2
            t2 = w_child < dm_parent
            # t2 = w_child > dm_parent
            if t2:
                gb_list_new.extend([ball_1, ball_2])
            else:
                gb_list_not.append(gb)
        else:
            gb_list_not.append(gb)
    return gb_list_new, gb_list_not


def normalized_ball(gb_list, gb_list_not, radius_detect):
    gb_list_temp = []
    for gb in gb_list:
        if len(gb) < 2:
            gb_list_not.append(gb)
        else:
            if get_radius(gb) <= 2 * radius_detect:
                gb_list_not.append(gb)
            else:
                ball_1, ball_2 = spilt_ball(gb)
                gb_list_temp.extend([ball_1, ball_2])
    return gb_list_temp, gb_list_not


def spilt_ball(gb):
    ball1 = []
    ball2 = []
    d_mat = squareform(pdist(gb))
    r, c = np.where(d_mat == np.max(d_mat))
    r1 = r[1]
    c1 = c[1]
    for j in range(0, len(gb)):
        if d_mat[j, r1] < d_mat[j, c1]:
            ball1.extend([gb[j, :]])
        else:
            ball2.extend([gb[j, :]])
    # if len(ball1) == 0 or len(ball2) == 0:
    #     print(ball1)
    #     print(ball2)
    ball1 = np.array(ball1)
    ball2 = np.array(ball2)
    return ball1, ball2


def get_dm(gb):
    num = len(gb)
    center = gb.mean(0)
    diff_mat = center - gb
    sq_diff_mat = diff_mat ** 2
    sq_distances = sq_diff_mat.sum(axis=1)
    distances = sq_distances ** 0.5
    sum_radius = 0
    for i in distances:
        sum_radius = sum_radius + i
    mean_radius = sum_radius / num
    if num > 2:
        return mean_radius
    else:
        return 1


def get_dm_2(gb):
    num = len(gb)
    center = gb.mean(0)
    diff_mat = center - gb
    sq_diff_mat = diff_mat ** 2
    sq_distances = sq_diff_mat.sum(axis=1)
    distances = sq_distances ** 0.5
    sum_radius = 0
    for i in distances:
        sum_radius = sum_radius + i
    mean_radius = sum_radius / num
    if mean_radius != 0:
        dm = num / sum_radius
    else:
        dm = num
    return dm


def get_radius(gb):
    center = gb.mean(0)
    diff_mat = center - gb
    sq_diff_mat = diff_mat ** 2
    sq_distances = sq_diff_mat.sum(axis=1)
    distances = sq_distances ** 0.5
    radius = max(distances)
    return radius


def gbc(data_list):
    gb_list_temp = [data_list]
    gb_list_not_temp = []
    while 1:
        # if gb_list_temp:
        #     gb_temp = gb_list_temp.copy()
        #     if gb_list_not_temp:
        #         gb_temp.extend(gb_list_not_temp)
        # else:
        #     gb_temp = gb_list_not_temp.copy()
        #     if gb_list_temp:
        #         gb_temp = gb_temp.extend(gb_list_temp)
        # center_list = []
        # for gb_ in gb_temp:
        #     center_list.append(gb_.mean(axis=0))
        # plt.figure(figsize=(8, 6))
        # data_display.plot_dot(data_list, c='black', linewidths=3)
        # data_display.plot_dot(center_list, c='r', label='center point', linewidths=3)
        # # plt.show()
        # data_display.draw_ball(gb_temp, c1='b', c2='b')
        ball_number_old = len(gb_list_temp) + len(gb_list_not_temp)
        gb_list_temp, gb_list_not_temp = division(gb_list_temp, gb_list_not_temp)
        ball_number_new = len(gb_list_temp) + len(gb_list_not_temp)
        if ball_number_new == ball_number_old:
            gb_list_temp = gb_list_not_temp
            break
    radius = []
    for gb in gb_list_temp:
        if len(gb) >= 2:
            radius.append(get_radius(gb))
    radius_median = np.median(radius)
    radius_mean = np.mean(radius)
    radius_detect = max(radius_median, radius_mean)
    gb_list_not_temp = []
    while 1:
        ball_number_old = len(gb_list_temp) + len(gb_list_not_temp)
        gb_list_temp, gb_list_not_temp = normalized_ball(gb_list_temp, gb_list_not_temp, radius_detect)
        ball_number_new = len(gb_list_temp) + len(gb_list_not_temp)
        if ball_number_new == ball_number_old:
            gb_list_temp = gb_list_not_temp
            break
    gb_list = gb_list_temp
    return gb_list
