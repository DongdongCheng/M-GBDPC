import numpy as np


class NNSearch:

    def __init__(self, dis_mat):
        self.dis_mat = dis_mat

    def get_dis_index(self):
        dis_mat = self.dis_mat
        n = dis_mat.shape[0]
        dis_index = {}
        nn = {}
        rnn = {}
        for i in range(0, n):
            dis = np.sort(dis_mat[i, :])
            index = np.argsort(dis_mat[i, :])
            dis_index[i] = [dis, index]
            nn[i] = []
            rnn[i] = []
        return dis_index, nn, rnn

    def natural_search(self):
        n = self.dis_mat.shape[0]
        dis_index, nn, rnn = self.get_dis_index()
        nb = [0] * n
        t = 0
        num_1 = 0
        num_2 = 0
        while t + 1 < n:
            for i in range(0, n):
                x = i
                y = dis_index[x][1][t + 1]

                nn[x].append(y)
                rnn[y].append(x)
                nb[y] = nb[y] + 1
            num_1 = nb.count(0)
            if num_1 != num_2:
                num_2 = num_1
            else:
                break
            t = t + 1
        return t, nn, rnn, dis_index


if __name__ == '__main__':
    print('this is a main process')
